﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreWithADO.Models
{
    public class ConnectionStr
    {
        public static string Connection {get;set;}
    }
}
