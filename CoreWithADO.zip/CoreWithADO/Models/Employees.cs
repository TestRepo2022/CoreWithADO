﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CoreWithADO.Models
{
    public class Employees
    {
        public int id { get; set; }
        public string fname { get; set; }
        public string lname { get; set; }
        public string email { get; set; }
        public string salary { get; set; }
        public string mobile { get; set; }
        public string gender { get; set; }

    }
}
